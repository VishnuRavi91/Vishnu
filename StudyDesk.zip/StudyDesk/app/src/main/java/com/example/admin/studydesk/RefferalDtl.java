package com.example.admin.studydesk;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.amlcurran.showcaseview.ShowcaseView;
import com.github.amlcurran.showcaseview.targets.Target;
import com.github.amlcurran.showcaseview.targets.ViewTarget;

import java.net.URL;

public class RefferalDtl extends AppCompatActivity {
    WebView webView;
    public static String link;
    Button btnHome;
    public static Boolean demo;
    TextView tvTitle;
    private ProgressDialog dialog;
    LinearLayout topbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refferal_dtl);
        webView=(WebView)findViewById(R.id.webView);
        btnHome=(Button)findViewById(R.id.btnHome);
        tvTitle=(TextView)findViewById(R.id.title) ;
        topbar=(LinearLayout)findViewById(R.id.topbar);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RefferalDtl.this, Second.class);
                startActivity(intent);
            }
        });
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
               WindowManager.LayoutParams.FLAG_SECURE);
        Window window =getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
// finally change the color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(getResources().getColor(R.color.colorPrimaryDark));
        }
        if (demo){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            Target listObjetivo = new ViewTarget(R.id.webView, this);
            tvTitle.setVisibility(View.GONE);
            topbar.setVisibility(View.GONE);
            /*new ShowcaseView.Builder(this, false)
                    .setTarget(listObjetivo)
                    .setContentTitle("")
                    .setContentText("Touch on the upper half of the screen to go forward. \n" +
                            "\n" +
                            "Swipe from left to right to go backward. \n" +
                            "\n" +
                            "Click ‘slide’ on the control bar to navigate to any slide. \n" +
                            "\n" +
                            "Hit back to exit.")
                    .setStyle(4)
                    .build();*/
        }else{
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            tvTitle.setVisibility(View.GONE);
            topbar.setVisibility(View.GONE);
        }
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);


       /* webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, android.os.Message resultMsg)
            {
                WebView.HitTestResult result = view.getHitTestResult();
                String data = result.getExtra();
                Context context = view.getContext();
               // Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(data));
               // context.startActivity(browserIntent);

                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + data));
                Intent webIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://www.youtube.com/watch?v=" + data));
                try {
                    context.startActivity(appIntent);
                } catch (ActivityNotFoundException ex) {
                    context.startActivity(webIntent);
                }

                return false;
            }
        });*/
        webView.setWebViewClient(new WebViewClient() {


            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {

                /*dialog = new ProgressDialog(RefferalDtl.this);
                dialog.setMessage("Loading..");
                dialog.show();*/
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
               /* if (dialog.isShowing()) {
                    dialog.dismiss();

                }*/
                super.onPageFinished(view, url);
            }

            @Override
            public void onLoadResource(WebView view, String url) {

                super.onLoadResource(view, url);
            }

            @Override
            public void onPageCommitVisible(WebView view, String url) {
                super.onPageCommitVisible(view, url);

            }

            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                webView.loadUrl("file:///android_asset/error.html");
            } });


        webView.loadUrl(link);
    }

   /*boolean doubleBackToExitPressedOnce;

    @Override
    public void onBackPressed() {
       // Log.i(TAG, "onBackPressed");

        if (doubleBackToExitPressedOnce) {
          //  Log.i(TAG, "double click");
           /* new AlertDialog.Builder(this)
                    .setTitle("Go to previous screen")
                    .setMessage("Continue?")
                    .setPositiveButton("Yes",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    finish();
                                }

                            }).setNegativeButton("No", null).show();*/
           /* finish();
            return;
        } else {
          //  Log.i(TAG, "single click");
            if (webView.canGoBack()) {
              //  Log.i(TAG, "canGoBack");
                webView.goBack();
            } else {
               // Log.i(TAG, "nothing to canGoBack");
            }
        }

        this.doubleBackToExitPressedOnce = true;
        if (getApplicationContext() == null) {
            return;
        } else {
          //  Toast.makeText(this, "Please click BACK again to go previous screen",
            //        Toast.LENGTH_SHORT).show();
        }
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }*/

}
